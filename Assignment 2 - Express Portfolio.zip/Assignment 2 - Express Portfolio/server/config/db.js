module.exports = 
{
    "URI": "mongodb+srv://florance:VD5oCrY5i3FbAzKh@cluster0.uatan.mongodb.net/florance?retryWrites=true&w=majority"

}